﻿using Bikecione.Core.Util.Google.Model;

namespace Bikecione.Core.Util.Geolocation
{
    public interface IGeolocation
    {
        AddressModel BuscaEnderecoPorLatitudeLongitude(GeoCodeModel geoCode, bool sensor = true);
        AddressModel BuscarPorEndereco(string logradouro, string numero, string cidade, string estado, bool sensor);
    }
}
