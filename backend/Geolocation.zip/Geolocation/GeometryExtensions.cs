﻿namespace Bikecione.Core.Util.Geolocation
{
    public static class GeometryExtensions
    {
        
    }
}
