﻿using System;
using System.Linq;
using System.Net;
using Bikecione.Core.Util.Geolocation;
using Bikecione.Core.Util.Google.Model;
using Newtonsoft.Json.Linq;

namespace Bikecione.Core.Util.Google
{
    public class GoogleMaps : IGeolocation
    {
        public AddressModel BuscaEnderecoPorLatitudeLongitude(GeoCodeModel geoCode, bool sensor)
        {
            try
            {
                AddressModel tempAddress = null;

                using (var webClient = new WebClient())
                {
                    string url =
                        string.Format("https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyB0L8qvc3w7RQ3RfAwDaoxx9RED3EFSSiE&latlng={0},{1}&sensor={2}",
                                      geoCode.Latitude, geoCode.Longitude, sensor);
                    string json =
                        webClient.DownloadString(url);
                    // Now parse with JSON.Net

                    JObject o = JObject.Parse(json);

                    var jsongmaps = (JArray)o["results"];

                    if (jsongmaps.Count > 0)
                    {
                        tempAddress = new AddressModel();

                        var jsonAddress = (JArray)jsongmaps[0].SelectToken("address_components");

                        for (int i = 0; i < jsonAddress.Count; i++)
                        {
                            string tipo = jsonAddress[i].SelectToken("types")[0].ToString();

                            switch (tipo)
                            {
                                case "route":
                                    {
                                        tempAddress.Endereco = jsonAddress[i].SelectToken("long_name").ToString();
                                        break;
                                    }
                                case "sublocality":
                                    {
                                        tempAddress.Bairro = jsonAddress[i].SelectToken("long_name").ToString();
                                        break;
                                    }
                                case "locality":
                                    {
                                        tempAddress.Cidade = jsonAddress[i].SelectToken("long_name").ToString();
                                        break;
                                    }
                                case "country":
                                    {
                                        tempAddress.Pais = jsonAddress[i].SelectToken("long_name").ToString();
                                        break;
                                    }
                                case "postal_code":
                                    {
                                        tempAddress.Cep = jsonAddress[i].SelectToken("long_name").ToString();
                                        break;
                                    }
                            }
                        }

                        if (jsongmaps[0].SelectToken("formatted_address") != null)
                            tempAddress.Formatted = jsongmaps[0].SelectToken("formatted_address").ToString();

                        tempAddress.GeoCode.Latitude = (jsongmaps.Count > 0
                                                            ? jsongmaps[0].SelectToken("geometry").SelectToken(
                                                                "location").SelectToken("lat").ToString()
                                                            : null);
                        tempAddress.GeoCode.Longitude = (jsongmaps.Count > 0
                                                             ? jsongmaps[0].SelectToken("geometry").SelectToken(
                                                                 "location").SelectToken("lng").ToString()
                                                             : null);
                    }
                }

                return tempAddress;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public AddressModel BuscarPorEndereco(string logradouro, string numero, string cidade, string estado, bool sensor)
        {
            try
            {
                AddressModel tempAddress = null;

                using (var webClient = new WebClient())
                {
                    string url = string.Format("https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyB0L8qvc3w7RQ3RfAwDaoxx9RED3EFSSiE&address={0}&sensor={1}", string.Format("{0}, {1}, {2}, {3}", logradouro, numero, cidade, estado), sensor);

                    string json =
                        webClient.DownloadString(url);
                    // Now parse with JSON.Net

                    JObject o = JObject.Parse(json);

                    var jsongmaps = (JArray)o["results"];

                    if (jsongmaps.Count > 0)
                    {
                        tempAddress = new AddressModel();

                        var jsonAddress = (JArray)jsongmaps[0].SelectToken("address_components");

                        foreach (JToken t in jsonAddress)
                        {
                            string tipo = t.SelectToken("types").Values().Contains("sublocality") ? "sublocality" : t.SelectToken("types")[0].ToString();


                            switch (tipo)
                            {
                                case "route":
                                    {
                                        tempAddress.Endereco = t.SelectToken("long_name").ToString();
                                        break;
                                    }
                                case "sublocality":
                                    {
                                        tempAddress.Bairro = t.SelectToken("long_name").ToString();
                                        break;
                                    }
                                case "administrative_area_level_4":
                                {
                                    tempAddress.Bairro = t.SelectToken("long_name").ToString();
                                    break;
                                }
                                case "locality":
                                    {
                                        tempAddress.Cidade = t.SelectToken("long_name").ToString();
                                        break;
                                    }
                                case "administrative_area_level_1":
                                    {
                                        tempAddress.Estado = t.SelectToken("long_name").ToString();
                                        break;
                                    }
                                case "country":
                                    {
                                        tempAddress.Pais = t.SelectToken("long_name").ToString();
                                        break;
                                    }
                                case "postal_code":
                                    {
                                        tempAddress.Cep = t.SelectToken("long_name").ToString();
                                        break;
                                    }
                            }
                        }

                        tempAddress.GeoCode.Latitude = (jsongmaps.Count > 0
                                                            ? jsongmaps[0].SelectToken("geometry").SelectToken(
                                                                "location").SelectToken("lat").ToString()
                                                            : null);
                        tempAddress.GeoCode.Longitude = (jsongmaps.Count > 0
                                                             ? jsongmaps[0].SelectToken("geometry").SelectToken(
                                                                 "location").SelectToken("lng").ToString()
                                                             : null);
                    }
                }

                return tempAddress;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
