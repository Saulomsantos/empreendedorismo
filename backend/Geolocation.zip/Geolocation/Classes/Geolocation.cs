﻿using GeoAPI.Geometries;
using NetTopologySuite;

namespace Bikecione.Core.Util.Google.Classes
{
    public class Geolocation
    {
        public static IPoint CreatePoint(double latitude, double longitude)
        {
            var geometryFactory = NtsGeometryServices.Instance.CreateGeometryFactory(srid: 4326);
            var currentLocation = geometryFactory.CreatePoint(new Coordinate(latitude, longitude));

            return currentLocation;
        }
    }
}
