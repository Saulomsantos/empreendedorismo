﻿namespace Bikecione.Core.Util.Google.Model
{
    public class GeoCodeModel
    {
        public string Latitude { get; set; }
        public string Longitude { get; set; }
    }
}
