﻿using System;
using System.Net;
using Bikecione.Core.Util.Google.Model;
using Newtonsoft.Json.Linq;

namespace Bikecione.Core.Util.Geolocation
{
    public class OpenCageData : IGeolocation
    {
        public AddressModel BuscaEnderecoPorLatitudeLongitude(GeoCodeModel geoCode, bool sensor = true)
        {
            throw new NotImplementedException();
        }

        public AddressModel BuscarPorEndereco(string logradouro, string numero, string cidade, string estado, bool sensor)
        {
            try
            {
                AddressModel tempAddress = null;

                using (var webClient = new WebClient())
                {
                    string url = string.Format("https://api.opencagedata.com/geocode/v1/json?key=7c676aad4d644e62bcc247dde48a1251&q={0}&pretty=1&no_annotations=1",  string.Format("{0}, {1}, {2}, {3}", logradouro, numero, cidade, estado));

                    string json =
                        webClient.DownloadString(url);
                    // Now parse with JSON.Net

                    JObject o = JObject.Parse(json);

                    var jsongmaps = (JArray)o["results"];

                    if (jsongmaps.Count > 0)
                    {
                        tempAddress = new AddressModel();

                        for (int i = 0; i < jsongmaps.Count; i++)
                        {
                            if (jsongmaps[i].SelectToken("components.country").ToString() ==  "Brazil")
                            {
                                tempAddress.GeoCode.Latitude = jsongmaps[i].SelectToken("bounds.southwest.lat").ToString();
                                tempAddress.GeoCode.Longitude = jsongmaps[i].SelectToken("bounds.southwest.lng").ToString();
                            }
                        }
                    }
                }

                return tempAddress;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
